package com.practice;

public class Book {

}
