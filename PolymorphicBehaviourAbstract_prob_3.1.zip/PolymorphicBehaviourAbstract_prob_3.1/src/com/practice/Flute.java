package com.practice;

public class Flute extends Instrument {

	@Override
	public void play() {
		System.out.println("Flute is playing  toot toot toot toot");

	}

}