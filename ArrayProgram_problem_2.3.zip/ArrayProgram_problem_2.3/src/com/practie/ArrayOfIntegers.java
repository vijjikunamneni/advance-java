package com.practie;
public class ArrayOfIntegers 
{  
    public static void main(String[] args)
    {  
        //Initialize array  
        int [] arr = new int [] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0};  
        int sum = 0;
        int len=arr.length;
        //Loop through the array to calculate sum of elements  
        for (int i = 0; i < 14; i++) {  
           sum = sum + arr[i];  
        }  
        System.out.println("Sum of all the elements of an array: " + sum); 
        arr[14]=sum;
        System.out.println("avg of all the elements of an array: " + sum/len);
        int avg=sum/len;
        arr[15]=avg;
       
        
    }
    public int smallNumber(int a[])
    {
    	int j,small=0;
    	for(j=0;j<a.length;j++)
    	{
    		if(a[j]<a[j+1])
        	{
        		small=a[j];
        	}
    	}
    	
    	return small;
    }
    
}  