package com.practice.book;

public class Book {
	String book_title_name;
	double book_price;
	
	public Book(String book_tittle, double book_price)
	{
		this.book_title_name= book_tittle;
		this.book_price = book_price;
	}
	
	public String getBook_tittle() {
		return book_title_name;
	}
	public void setBook_tittle(String book_tittle) {
		this.book_title_name = book_tittle;
	}
	public double getBook_price() {
		return book_price;
	}
	public void setBook_price(double book_price) {
		this.book_price = book_price;
	}
	
	 public void display(){
	      System.out.println("book_title: "+this.book_title_name);
	      System.out.println("book_price: "+this.book_price);
	      
	   }
	
}
