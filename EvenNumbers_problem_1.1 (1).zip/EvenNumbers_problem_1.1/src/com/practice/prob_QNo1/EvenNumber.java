package com.practice.prob_QNo1;

import java.util.Scanner;

public class EvenNumber 
{
	public static void main(String[] args)
	{
		int number = 0, i = 0;
		Scanner X = new Scanner(System.in);
		System.out.print("Enter value n : ");
		number = X.nextInt();
		for (i = 1; i < number; i++)
		{
			if (i % 2 == 0)
				System.out.print(i + " ");
		}
		System.out.println();
	}
}
